function func_calibration_plot(initial_OP, final_OP, ref_curve )
% This function creates the crossplot of the initial, final and reference data 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%----------------------- Set up the plot template -------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

set(0,'DefaultAxesFontSize', 16, 'DefaultAxesLineWidth', 1, ...
'DefaultLineLineWidth', 1.5, 'DefaultAxesFontName', 'Latin Modern Math', ...
'DefaultTextFontName', 'Latin Modern Math', ...
'DefaultTextFontSize', 16, ...
'defaultAxesTickLabelInterpreter', 'latex', ...
'defaultLegendInterpreter', 'latex', ...
'defaultTextInterpreter', 'latex', ...
'defaultColorbarTickLabelInterpreter', 'latex', ...
'defaultPolaraxesTickLabelInterpreter', 'latex', ...
'defaultTextarrowshapeInterpreter', 'latex', ...
'defaultTextboxshapeInterpreter', 'latex', ...
'DefaultLegendBox','on', 'DefaultLegendFontSize', 16, ...
'DefaultAxesBoxStyle', 'back', 'DefaultAxesBox', 'off')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x1             = initial_OP(:,1);
y1             = initial_OP(:,2);
plot_x1_length = size(x1,1);

x2             = final_OP(:,1);
y2             = final_OP(:,2);
plot_x2_length = size(x2,1);

x3             = ref_curve(:,1);
y3             = ref_curve(:,2);
plot_x3_length = size(x3,1);


% Figure generation
file_name='Crossplot';
save_file_name='Crossplot';
f = figure("Position",[300 100 720 500]); % The first 2 arguments define the position, the second 2 arguments define the size
t = tiledlayout(1,1,'TileSpacing','compact','Padding','compact'); 
title0 = title(file_name);
set(title0,'interpreter','latex','fontsize', 16,'Color','k');
hold on; box on; grid on;

plot(x1,y1,'--ro','LineWidth',1,'Color','black','LineStyle','-.','Marker','none','MarkerSize',9,'MarkerIndices',[1:1:plot_x1_length]);
plot(x2,y2,'--ro','LineWidth',1.5,'Color','blue','LineStyle','-','Marker','none','MarkerSize',9,'MarkerIndices',[1:1:plot_x2_length]);
plot(x3,y3,'--ro','LineWidth',2,'Color','red','LineStyle','--','Marker','none','MarkerSize',9,'MarkerIndices',[1:round(0.04*plot_x3_length):plot_x3_length]);

legend(["Initial guess","Final guess", "Ref. data"],'FontSize',16,'position',[.65 .2 .05 .05]);

saveas(gcf,strcat(save_file_name,'.png'), 'png')

end