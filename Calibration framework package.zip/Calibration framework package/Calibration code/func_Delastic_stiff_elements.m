function [Delastic_stiff] = func_Delastic_stiff_elements 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% =============== CONSTITUTIVE MATRIX (3x3 for 2D problems) ===============
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Include global variables
func_include_flags;

% Extract material properties
mu = materialprops(1);          % Shear modulus
nu = materialprops(2);          % Poisson's ratio
E = 2*mu*(1+nu) * 10;          % Young's modulus ( Mulitplied by a factor of 100 to make the elements stiffer)
planestrain = materialprops(3); % Planestress vs planestrain

% Note: planestrain = 0 => plane stress 
%       planestrain = 1 => plane strain

% Initialize the constitutive matrix D with zeros (3x3 for 2D problems)
Delastic_stiff = zeros(3,3);

% Compute the non-zero components of the elastic constitutive matrix D 
if planestrain == 0     % plane stress formulation

    Delastic_stiff(1,1) = E/(1-nu^2);
    Delastic_stiff(2,2) = E/(1-nu^2);
    Delastic_stiff(3,3) = E/(1-nu^2) * (1-nu)/2;
    Delastic_stiff(1,2) = E/(1-nu^2) * nu;
    Delastic_stiff(2,1) = E/(1-nu^2) * nu;

elseif planestrain == 1 % plane strain formulation

    Delastic_stiff(1,1) = E/((1+nu)*(1-2*nu)) * (1-nu);
    Delastic_stiff(2,2) = E/((1+nu)*(1-2*nu)) * (1-nu);
    Delastic_stiff(3,3) = E/((1+nu)*(1-2*nu)) * (1-2*nu)/2;
    Delastic_stiff(1,2) = E/((1+nu)*(1-2*nu)) * nu;
    Delastic_stiff(2,1) = E/((1+nu)*(1-2*nu)) * nu;

else % neither plane stress nor plane strain 

    print("Check your inputs in the material properties")

end