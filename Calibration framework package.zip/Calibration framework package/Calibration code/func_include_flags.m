%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ======================= DEFINE GLOBAL VARIABLES =========================
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% FEM MODEL PARAMETERS 
global nprops materialprops ncoord ndof nnodes coords nelem maxnodes connect nelnodes elident_vec nfix fixnodes ndof2
ndof2 = 2;

% NONLOCAL GRADIENT PARAMETER 
% g = lc^2/2, lc = characteristic length

% MAZAR'S DAMAGE MODEL PARAMETERS
global alpha_val beta_val e_delta dmax

% ADAPTIVE LOAD AND PLOTTING PARAMETERS
global min_iter max_iter max_accept_iter dlfactor_incr_threshold increment_plot_threshold loadfactor_plot_threshold

% SOLVER SCHEME
% SolverID: 1 - Local, 2 - Nonlocal Gradient, 3 - Nonlocal Integral
% TangentID: 1 - Analytical, 2 - Numerical
% RoutineID 1 - UAL, 2 - NR 
global SolverID TangentID

% global estar_type damage_model_type k_damage_parameter
global e_delta_stiffness_factor 
e_delta_stiffness_factor = 1000;
