function [e_f_factor_opt] = func_calc_opt_e_f_factor(k1, alpha_val, beta_val, e_delta, lc, alpha_localizing, dmax, e_f_factor_initial, e_i)
% This function calculates the minimum value of e_f_factor for a given
% value of k1, edf, e_i, a, b and e_delta

flag_e_f = 0;

for e_f_factor_test = e_f_factor_initial : 0.1 : 1000

    % Calculate e_f based on the mazar's model parameters
    for kappa_test = e_i : 1e-5 : 10
        omega = max(0, dmax*(1 - e_delta*(1-alpha_val)/kappa_test - alpha_val/exp(beta_val*(kappa_test-e_delta))));

        if omega >= e_f_factor_test*dmax
            e_f_test = kappa_test;
            break
        end
    end

    g_test = (1 - ((1 - k1) * ((e_f_test - kappa_test)/(e_f_test - e_delta)))^alpha_localizing) * ((lc^2)/2);

    if g_test > 0
        e_f_factor_opt = e_f_factor_test;        
        break
    end
   
end

end




