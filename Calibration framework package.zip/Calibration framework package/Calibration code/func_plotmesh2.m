function func_plotmesh2(ID_element_stiff_set, save_disp, main_file_path,image_storage_path,coords,connect,nelem,damage,elocal,enonlocal,prin_strain_1, prin_strain_2, elocal_shear_strain, nelnodes,color,model_name,inc_success_counter,last_iteration,increment,loadfactor,solver_string,tangent_string,SolverID,ID_dofs_list_x,ID_dofs_list_y,dofs,Load_percentage,RoutineID,exx,eyy,exy)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% =============================== PLOTTING ================================
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Adjust nonlocal strain graph c-axis limits
% caxis_minval = min(min(elocal), min(enonlocal));
% caxis_maxval = max(max(elocal), max(enonlocal));

if RoutineID == 2 % Newton Raphson
    load_value = loadfactor * 100;
elseif RoutineID == 1 % UAL
    load_value = Load_percentage;
end
% Initialize figure
f = figure("Position",[400 200 1500 800],'Visible', 'off');
t = tiledlayout(2,2,'TileSpacing','Compact');
title(t, strcat(model_name + ": Increment #" + num2str(increment) + " - Iteration #" + num2str(last_iteration) + " - Load percentage " + num2str(load_value)) + " - Displacement " + num2str(save_disp(end)), 'fontweight','bold');

%%%%%%%%%%%%%%%%%%%%%%%%%

% 
% % -------------------------------------------------------------------------
% % ------------------------ TEST ------------------------
% % -------------------------------------------------------------------------
% % nexttile
% hold on; box on;
% colormap(jet);  %https://www.mathworks.com/help/matlab/ref/colormap.html
% f2D_4 = [1,2,3,4];
% caxis([0 1])
% for lmn = 1:nelem
%     for i = 1:nelnodes(lmn)
%         x(i,1:2) = coords(1:2,connect(i,lmn));
%         if ismember(lmn,ID_element_stiff_set)
%             col(i,1) = 1;
%         else
%             col(i,1) = 0;
%         end
%     end
% 
%     if (nelnodes(lmn)==4)
%         patch('Vertices',x,'Faces',f2D_4,'FaceVertexCData',col,'FaceColor','interp','EdgeColor','black');
%     else
%         disp("Check your nelnodes")
%     end
% end
% colorbar
% title("Test element contours", 'fontweight','bold');
% axis equal
% hold off
% 
% cd(image_storage_path)
% saveas(f, strcat(model_name + "contours" + solver_string + "_" + tangent_string + "_inc_" + int2str(increment) + ".png"))
% close all
% cd(main_file_path)



%%%%%%%%%%%%%%%%%%%%%%%%%

% -------------------------------------------------------------------------
% ------------------------ PLOTTING DAMAGE CONTOUR ------------------------
% -------------------------------------------------------------------------
nexttile
hold on; box on;
colormap(jet);  %https://www.mathworks.com/help/matlab/ref/colormap.html
% colormap([204, 204, 204] / 255);
f2D_4 = [1,2,3,4];
caxis([0 1])
for lmn = 1:nelem
    for i = 1:nelnodes(lmn)
        x(i,1:2) = coords(1:2,connect(i,lmn));
        col(i,1) = damage(connect(i,lmn));
    end

    if (nelnodes(lmn)==4)
        patch('Vertices',x,'Faces',f2D_4,'FaceVertexCData',col,'FaceColor','interp','EdgeColor','black');
    else
        disp("Check your nelnodes")
    end
end
colorbar
title("Damage contours", 'fontweight','bold');
axis equal
hold off

% % -------------------------------------------------------------------------
% % ----------------------- PLOTTING ELOCAL CONTOUR -------------------------
% % -------------------------------------------------------------------------
% nexttile
% hold on; box on;
% colormap(jet);  %https://www.mathworks.com/help/matlab/ref/colormap.html
% f2D_4 = [1,2,3,4];
% %caxis([0 0.0025]);
% for lmn = 1:nelem
%     for i = 1:nelnodes(lmn)
%         x(i,1:2) = coords(1:2,connect(i,lmn));
%         col(i,1) = elocal(connect(i,lmn));
%     end
% 
%     if (nelnodes(lmn)==4)
%         patch('Vertices',x,'Faces',f2D_4,'FaceVertexCData',col,'FaceColor','interp','EdgeColor','none');
%     else
%         disp("Check your nelnodes")
%     end
% end
% colorbar
% title("Local strain contours", 'fontweight','bold');
% axis equal
% hold off
% 
% 
% % -------------------------------------------------------------------------
% % --------------------- PLOTTING ENONLOCAL CONTOUR ------------------------
% % -------------------------------------------------------------------------
% if SolverID == 2
%     nexttile
%     hold on; box on;
%     colormap(jet);  %https://www.mathworks.com/help/matlab/ref/colormap.html
%     f2D_4 = [1,2,3,4];
%     %caxis([0 0.001]);
%     for lmn = 1:nelem
%         for i = 1:nelnodes(lmn)
%             x(i,1:2) = coords(1:2,connect(i,lmn));
%             col(i,1) = enonlocal(connect(i,lmn));
%         end
% 
%         if (nelnodes(lmn)==4)
%             patch('Vertices',x,'Faces',f2D_4,'FaceVertexCData',col,'FaceColor','interp','EdgeColor','none');
%         else
%             disp("Check your nelnodes")
%         end
%     end
%     colorbar
%     title("Nonlocal strain contours", 'fontweight','bold');
%     axis equal
%     hold off
% end
% 
% 
% % -------------------------------------------------------------------------
% % ------------------------ PLOTTING Y DISPLACEMENT CONTOUR ------------------------
% % -------------------------------------------------------------------------
% dofs_y = dofs(ID_dofs_list_y,1);
% nexttile
% hold on; box on;
% colormap(jet);  %https://www.mathworks.com/help/matlab/ref/colormap.html
% f2D_4 = [1,2,3,4];
% % caxis([-1e-4 1e-4])
% for lmn = 1:nelem
%     for i = 1:nelnodes(lmn)
%         x(i,1:2) = coords(1:2,connect(i,lmn));
%         col(i,1) = dofs_y(connect(i,lmn));
%     end
% 
%     if (nelnodes(lmn)==4)
%         patch('Vertices',x,'Faces',f2D_4,'FaceVertexCData',col,'FaceColor','interp','EdgeColor','none');
%     else
%         disp("Check your nelnodes")
%     end
% end
% colorbar
% title("Y Displacement contours", 'fontweight','bold');
% axis equal
% hold off
% 
% -------------------------------------------------------------------------
cd(image_storage_path)
saveas(f, strcat(model_name + "contours" + solver_string + "_" + tangent_string + "_inc_" + int2str(increment) + ".png"))
close all
cd(main_file_path)
% -------------------------------------------------------------------------
% 
% if RoutineID == 1 % UAL only
%     % Initialize figure
%     f1 = figure("Position",[400 200 1500 800],'Visible', 'off');
%     t1 = tiledlayout(2,2,'TileSpacing','Compact');
%     title(t1, strcat(model_name + ": Increment #" + num2str(increment) + " - Iteration #" + num2str(last_iteration) + " - Load percentage " + num2str(load_value) + " - Displacement " + num2str(save_disp(end))), 'fontweight','bold');
% 
%     % -------------------------------------------------------------------------
%     % ----------------- PLOTTING PRINCIPAL STRAIN 1 CONTOUR -------------------
%     % -------------------------------------------------------------------------
%     nexttile
%     hold on; box on;
%     colormap(jet);  %https://www.mathworks.com/help/matlab/ref/colormap.html
%     f2D_4 = [1,2,3,4];
%     %caxis([0 0.0025]);
%     for lmn = 1:nelem
%         for i = 1:nelnodes(lmn)
%             x(i,1:2) = coords(1:2,connect(i,lmn));
%             col(i,1) = prin_strain_1(connect(i,lmn));
%         end
% 
%         if (nelnodes(lmn)==4)
%             patch('Vertices',x,'Faces',f2D_4,'FaceVertexCData',col,'FaceColor','interp','EdgeColor','none');
%         else
%             disp("Check your nelnodes")
%         end
%     end
%     colorbar
%     title("Principal strain 1 contours", 'fontweight','bold');
%     axis equal
%     hold off
% 
%     % -------------------------------------------------------------------------
%     % ----------------- PLOTTING PRINCIPAL STRAIN 2 CONTOUR -------------------
%     % -------------------------------------------------------------------------
%     nexttile
%     hold on; box on;
%     colormap(jet);  %https://www.mathworks.com/help/matlab/ref/colormap.html
%     f2D_4 = [1,2,3,4];
%     %caxis([0 0.0025]);
%     for lmn = 1:nelem
%         for i = 1:nelnodes(lmn)
%             x(i,1:2) = coords(1:2,connect(i,lmn));
%             col(i,1) = prin_strain_2(connect(i,lmn));
%         end
% 
%         if (nelnodes(lmn)==4)
%             patch('Vertices',x,'Faces',f2D_4,'FaceVertexCData',col,'FaceColor','interp','EdgeColor','none');
%         else
%             disp("Check your nelnodes")
%         end
%     end
%     colorbar
%     title("Principal strain 2 contours", 'fontweight','bold');
%     axis equal
%     hold off
% 
%     % -------------------------------------------------------------------------
%     % -------------------- PLOTTING SHEAR STRAIN CONTOUR ----------------------
%     % -------------------------------------------------------------------------
%     nexttile
%     hold on; box on;
%     colormap(jet);  %https://www.mathworks.com/help/matlab/ref/colormap.html
%     f2D_4 = [1,2,3,4];
%     %caxis([0 0.0025]);
%     for lmn = 1:nelem
%         for i = 1:nelnodes(lmn)
%             x(i,1:2) = coords(1:2,connect(i,lmn));
%             col(i,1) = elocal_shear_strain(connect(i,lmn));
%         end
% 
%         if (nelnodes(lmn)==4)
%             patch('Vertices',x,'Faces',f2D_4,'FaceVertexCData',col,'FaceColor','interp','EdgeColor','none');
%         else
%             disp("Check your nelnodes")
%         end
%     end
%     colorbar
%     title("estar contour (with strain invariants)", 'fontweight','bold');
%     axis equal
%     hold off
% 
%     % -------------------------------------------------------------------------
%     % ------------------------ PLOTTING X DISPLACEMENT CONTOUR ------------------------
%     % -------------------------------------------------------------------------
%     dofs_y = dofs(ID_dofs_list_x,1);
%     nexttile
%     hold on; box on;
%     colormap(jet);  %https://www.mathworks.com/help/matlab/ref/colormap.html
%     f2D_4 = [1,2,3,4];
%     % caxis([-1e-4 1e-4])
%     for lmn = 1:nelem
%         for i = 1:nelnodes(lmn)
%             x(i,1:2) = coords(1:2,connect(i,lmn));
%             col(i,1) = dofs_y(connect(i,lmn));
%         end
% 
%         if (nelnodes(lmn)==4)
%             patch('Vertices',x,'Faces',f2D_4,'FaceVertexCData',col,'FaceColor','interp','EdgeColor','none');
%         else
%             disp("Check your nelnodes")
%         end
%     end
%     colorbar
%     title("X Displacement contours", 'fontweight','bold');
%     axis equal
%     hold off
% 
%     % -------------------------------------------------------------------------
%     cd(image_storage_path)
%     saveas(f1, strcat(model_name + "Principal_strain_contours" + solver_string + "_" + tangent_string + "_inc_" + int2str(increment) + ".png"))
%     close all
%     cd(main_file_path)
%     % -------------------------------------------------------------------------
% end
% 
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %------------------------ Plot strain exx, eyy,exy contours --------------------
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% % Initialize figure
%     f2 = figure("Position",[400 200 1500 800],'Visible', 'off');
%     t2 = tiledlayout(2,2,'TileSpacing','Compact');
%     title(t2, strcat(model_name + ": Increment #" + num2str(increment) + " - Iteration #" + num2str(last_iteration) + " - Load percentage " + num2str(load_value) + " - Displacement " + num2str(save_disp(end))), 'fontweight','bold');
% 
%     % -------------------------------------------------------------------------
%     % ----------------- PLOTTING exx CONTOUR -------------------
%     % -------------------------------------------------------------------------
%     nexttile
%     hold on; box on;
%     colormap(jet);  %https://www.mathworks.com/help/matlab/ref/colormap.html
%     f2D_4 = [1,2,3,4];
%     %caxis([0 0.0025]);
%     for lmn = 1:nelem
%         for i = 1:nelnodes(lmn)
%             x(i,1:2) = coords(1:2,connect(i,lmn));
%             col(i,1) = exx(connect(i,lmn));
%         end
% 
%         if (nelnodes(lmn)==4)
%             patch('Vertices',x,'Faces',f2D_4,'FaceVertexCData',col,'FaceColor','interp','EdgeColor','none');
%         else
%             disp("Check your nelnodes")
%         end
%     end
%     colorbar
%     title("exx contours", 'fontweight','bold');
%     axis equal
%     hold off
% 
%     % -------------------------------------------------------------------------
%     % ----------------- PLOTTING eyy CONTOUR -------------------
%     % -------------------------------------------------------------------------
%     nexttile
%     hold on; box on;
%     colormap(jet);  %https://www.mathworks.com/help/matlab/ref/colormap.html
%     f2D_4 = [1,2,3,4];
%     %caxis([0 0.0025]);
%     for lmn = 1:nelem
%         for i = 1:nelnodes(lmn)
%             x(i,1:2) = coords(1:2,connect(i,lmn));
%             col(i,1) = eyy(connect(i,lmn));
%         end
% 
%         if (nelnodes(lmn)==4)
%             patch('Vertices',x,'Faces',f2D_4,'FaceVertexCData',col,'FaceColor','interp','EdgeColor','none');
%         else
%             disp("Check your nelnodes")
%         end
%     end
%     colorbar
%     title("eyy contours", 'fontweight','bold');
%     axis equal
%     hold off
% 
%     % -------------------------------------------------------------------------
%     % -------------------- PLOTTING exy CONTOUR ----------------------
%     % -------------------------------------------------------------------------
%     nexttile
%     hold on; box on;
%     colormap(jet);  %https://www.mathworks.com/help/matlab/ref/colormap.html
%     f2D_4 = [1,2,3,4];
%     %caxis([0 0.0025]);
%     for lmn = 1:nelem
%         for i = 1:nelnodes(lmn)
%             x(i,1:2) = coords(1:2,connect(i,lmn));
%             col(i,1) = exy(connect(i,lmn));
%         end
% 
%         if (nelnodes(lmn)==4)
%             patch('Vertices',x,'Faces',f2D_4,'FaceVertexCData',col,'FaceColor','interp','EdgeColor','none');
%         else
%             disp("Check your nelnodes")
%         end
%     end
%     colorbar
%     title("exy contours", 'fontweight','bold');
%     axis equal
%     hold off
% 
%     % -------------------------------------------------------------------------
%     cd(image_storage_path)
%     saveas(f2, strcat(model_name + "Strain_contours" + solver_string + "_" + tangent_string + "_inc_" + int2str(increment) + ".png"))
%     close all
%     cd(main_file_path)
%     % -------------------------------------------------------------------------

end













