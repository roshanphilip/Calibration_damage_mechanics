function [e_princ_i,e_princ_ii] = func_calc_principal_strains(exx, eyy, gxy)

% Compute the principal strains
e_princ_i = (exx + eyy)/2 + sqrt(((exx-eyy)/2)^2 + (gxy/2)^2);
e_princ_ii = (exx + eyy)/2 - sqrt(((exx-eyy)/2)^2 + (gxy/2)^2);

end