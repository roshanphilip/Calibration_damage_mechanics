function [MATLAB_OP] = func_MATLAB_loss_function_UAL(x, num_function_calls, p_main_file_path, model_name_input)
% This function is calculates the loss function based on the UAL algorithm
% based on the material parameter inputs from python

% Unroll the input calibration guesses
x1 = x(1);
x2 = x(2);
x3 = x(3);
x4 = x(4);
x5 = x(5);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%============================ USER INPUTS ================================%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% % Enter location of current file path
% main_file_path='C:\Users\rs7625\Desktop\Calibration_UAL';
% % Enter location of results storage folder
% save_path='C:\Users\rs7625\Desktop\Calibration_UAL\Saved Files';
% % Enter the location of the folder for permanentally storing the data file at the end of a run
% perm_storage_path = 'C:\Users\rs7625\Desktop\Calibration_UAL\Perm Storage';

% Identify the main, saved and permanent storage file paths
sf                ='\Saved Files';
ps                ='\Perm Storage';
im                ='\Images';

main_file_path     = p_main_file_path;
save_path          = strcat(main_file_path,sf);
perm_storage_path  = strcat(main_file_path,ps);
image_storage_path = strcat(main_file_path,im);

cd (main_file_path);

% Enter your model name
model_name = string(model_name_input);

% Enter convergence tolerance
tolerance=1e-8;

% For UAL routine:
% Enter the upper limit of ArcLength
ArcLength_upper_limit = 3e-3;
% Enter the lower limit of ArcLength
ArcLength_lower_limit = 1e-8;

% I] Local Damage
% a) Choose the solution scheme to be used:
Scheme_ID = 1;            % 1 - Partitioned Consistent (PC) scheme   2 - Partitioned Non-Consistent (PNC) scheme
% b) Choose a strain tolerance (ST) value
ST = 0;                % Recommended range: 1e-5 to 1e-7

% Choose the localizing gradient parameter values below:
k1_parameter               = 1;  % This parameter scales the initial value of length scale g (set to about 1%)
edf_parameter              = 0.9;  % This parameters determines the value of nonlocal strain (e_i) after which the length scale g is allowed to grow
alpha_localizing_parameter = 1;    % This parameter determines if the growth of the localizing length scale g is linear or expoential   1 - Linear
e_f_factor_parameter       = 0.99; % At damage = e_f_factor * dmax, e_nonlocal = e_f (value <1)

% Choose the equivalent strain and damage model
func_include_flags_damage_estar_variables;
estar_type = 1;          % 1 - Modified Von Mises equivalent strain  2 - Tension equivalent strain
damage_model_type = 2;   % 1 - Mazars damage model  2 - Geers damage model
k_damage_parameter = 10; % Modified Von Mises equivalent strain control paramter (Recommended value: 10)

% =========================================================================
% ============================== IMPORTANT ===============================%
% =========================================================================
% ------------------------ Parameters file guide --------------------------
% -------------------------------------------------------------------------
% Choose solution scheme
% SolverID:        1 - Local                (No._DOF_per_node: 2)
%                  2 - Nonlocal Gradient    (No._DOF_per_node: 3)

% NOTE: Ensure that the "No._DOF_per_node" is updated in the parameter file
% when switching from Local to Nonlocal Gradient model

% TangentID:       1 - Analytical
%                  2 - Numerical
%
% RoutineID:       1 - Unified Arclength
%                  2 - Newton Raphson
%
% Constraint type: 1 - Cylindrical
%                  2 - Spherical
% -------------------------------------------------------------------------


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ======================= INCLUDE GLOBAL VARIABLES ========================
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
func_include_flags;

% Assign the values for the calibration parameters
alpha_val    = x1;
beta_val     = x2;
e_delta      = x3;
lc_parameter = x4;
plot_switch  = x5;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ============================ LOAD INPUT FILE ============================
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

infile     = fopen(model_name + "_parameters.txt",'r');
[SolverID,TangentID,RoutineID,ncoord,ndof, ...
    increment,inc_success_counter,min_iter,max_iter,max_accept_iter, ...
    loadfactor,dlfactor,dlfactor_incr_threshold,increment_plot_threshold,loadfactor_plot_threshold, ...
    flaglf,countflaglf,incrflag,flagplot, ...
    ndomains,nprops,materialprops,dmax, ...
    nnodes,coords,nelem,maxnodes,connect,nelnodes,elident_vec,nfix,fixnodes,ArcLength_0,Constraint_type,delta_m_bar_0,Applied_Force_Load,nu] = func_read_input_file(infile);

fclose(infile);

if RoutineID==1
    strain_tolerance = ST;
else
    strain_tolerance = [];
end

% -------------------------------------------------------------------------
% Find the number of elements attached to each node
num_elem_at_node = zeros(nnodes,1);
for i = 1:size(connect,1)
    for j = 1:size(connect,2)
        num_elem_at_node(connect(i,j)) = num_elem_at_node(connect(i,j)) + 1;
    end
end

func_include_flags_localizing_gradient;

k1               = k1_parameter;
lc               = lc_parameter;
edf              = edf_parameter;
alpha_localizing = alpha_localizing_parameter;
e_f_factor       = e_f_factor_parameter;


% Calculate e_i
e_i = edf * e_delta;

% Calculate e_f based on the mazar's model parameters
for kappa = 0 : 1e-5 : 10
    omega = max(0, dmax*(1 - e_delta*(1-alpha_val)/kappa - alpha_val/exp(beta_val*(kappa-e_delta))));

    if omega >= e_f_factor*dmax
        e_f = kappa;
        break
    end
end

% Find the minimum e_f_factor for which g is not negative

for kappa = e_i : 1e-5 : 10
    g_test = (1 - ((1 - k1) * ((e_f - kappa)/(e_f - e_delta)))^alpha_localizing) * ((lc^2)/2) ;

    if g_test < 0
        % [e_f_factor_opt] = func_calc_opt_e_f_factor(k1, alpha_val, beta_val, e_delta, lc, alpha_localizing, dmax, e_f_factor, e_i);
        disp('Choose a higher e_f_factor')
        MATLAB_OP = [];
        return
    end

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ================== SPECIFY VALUES FOR GLOBAL VARIABLES ==================
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% -------------------------------------------------------------------------
% Element length
lelem = coords(1,2) - coords(1,1);

if SolverID == 1
    solver_string = "Local";
elseif SolverID == 2
    solver_string = "Nonlocal_gradient";
elseif SolverID == 3
    solver_string = "Nonlocal_integral";
else
    disp("Check your SolverID - FEM Main Script")
end

if TangentID == 1
    tangent_string = "Analytical";
elseif TangentID == 2
    tangent_string = "Numerical";
else
    disp("Check your TangentID - FEM_Main_Script")
end

if RoutineID == 1
    routine_string = "UAL";
elseif RoutineID == 2
    routine_string = "NR";
elseif RoutineID == 3
    routine_string = "FAL";
else
    disp("Check your RoutineID - FEM_Main_Script")
end

% -------------------------------------------------------------------------
% Calculate matrix with neighbouring points and their weights for the nonlocal integral method
if SolverID == 1 || SolverID == 2
    n_hood = [];
    weights = [];
elseif SolverID == 3
    [n_hood, weights] = func_nhood_gausspts(lc);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ====================== SETTING UP MATRICES/VECTORS ======================
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Delastic     = func_Delastic;           % Calculate the elastic constitutive matrix D (3x3 for 2D problems)
fixnodes     = (sortrows(fixnodes'))';  % Ensure that the fixnodes matrix lists the prescribed displacements in ascending order of nodes and dofs (as in the global system)
plot_storage = zeros(1,2);              % Saves the converged displacement and reaction forces for all converged increments

% UAL input initialization
conv_delta_dofs                      = zeros(ndof*nnodes,1);                             % Contains converged values of delta_dofs
conv_delta_f_rct_disp_ebc            = zeros(nfix,1);                                    % Contain converged values of delta_f_rct_disp_ebc
nfree                                = (ndof*nnodes)-nfix;                               % Contains number of free nodes
Applied_Displacement_Load            = (fixnodes(3,:))';                                 % Contains loads applied at the prescribed nodes
delta_m_bar                          = delta_m_bar_0;                                    % Initial value of Arc Length load factor
history_var_mat                      = zeros(nelem,4);                                   % Contains the values of the history variable (damage or kappa) at each Gauss point
storage_localizing_gradient_g_conv   = zeros(nelem,4,10);                                % Contains the history of the length scale g value at each gauss point throughout the simulation
storage_localizing_gradient_nle_conv = zeros(nelem,4,10);                                % Contains the history of the nonlocal strain value at each gauss point throughout the simulation
[history_var_mat_conv, strain_var_mat_conv]   = deal(zeros(nelem,4));                    % Contains the values of the strain variable (damage or kappa) at each Gauss point
[u_bar,u_bar_conv]                   = deal(zeros(size(Applied_Displacement_Load,1),1)); % Prescribed displacement vector
Res_F_F                              = zeros(nfree,1);                                   % Initialize the Residual (Free dofs) vector
Res_F_E_rct                          = zeros(nfix,1);                                    % Initialize the Residual (Prescribed dofs) vector
[convergance_flag,delta_e_nl_conv,e_nl_conv,g_constraint,ArcLength,Load_percentage_last_saved,opt_counter,delta_m_bar_conv,delta_u_bar_conv,delta_u_f_conv,delta_f_rct_disp_ebc_conv,delta_u_bar,delta_u_f,delta_f_rct_disp_ebc,m_bar,u_f,f_rct_disp_ebc,m_bar_conv,u_f_conv,f_rct_disp_ebc_conv]=deal(zeros);

% NR input initialization
[dofs_stored,dofs]          = deal(zeros(ndof*nnodes,1)); % Contains the values of displacements at each node
local_strain_mat_stored     = zeros(nelem,4);       % Contains the values of local equivalent strain at each Gauss point
nonlocal_strain_mat_stored  = zeros(nelem,4);       % Contains the values of nonlocal equivalent strain at each Gauss point
history_var_mat_stored      = zeros(nelem,4);       % Contains the values of the history variable (damage or kappa) at each Gauss point
stress_s1_mat_stored        = zeros(nelem,4);       % Contains the values of 1st principal stress at each Gauss point
xcoord_GP_mat               = zeros(nelem,4);       % Contains the x-coordinates of all Gauss points
ycoord_GP_mat               = zeros(nelem,4);       % Contains the y-coordinates of all Gauss points
[sum_internal_force,sum_external_force,f_reaction_sum_x,f_reaction_sum_y] =deal(0);

% FAL input initialization
if RoutineID == 3
    % Identify the position of the free and essential nodes
    [~, ~,~,ID_dofs_list_at_ebc,ID_dofs_list_at_nbc,ID_q_dofs,n_essential,n_free]         = func_partitiond_FAL(fixnodes, dofs_stored,nnodes,Applied_Force_Load,[],[],[],1);
    del_u_bar                                                                             = zeros(size(ID_dofs_list_at_ebc,1),1);
    [lambda,lambda_last_converged,delta_lambda_lastconverged,delta_lambda]                = deal(0);
    [u_last_converged,delta_u_last_converged,delta_u]                                     = deal(zeros((size(ID_dofs_list_at_ebc,1)+size(ID_dofs_list_at_nbc,1)),1));
    del_u_f                                                                               = zeros(size(ID_dofs_list_at_nbc,1),1);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ======================= GAUSS POINTS COORDINATES ========================
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Compute the 4x4 shape function matrix (constant for all our elements)
xilist  = func_integrationpoints;  % Positions of integration points in parent element
for integ_point = 1:4
    xi = xilist(:,integ_point);                 % Size: 2x1
    N(:,integ_point) = func_shapefunctions(xi); % Size: 4x1
    dNdx = func_shapefunctionderivs(xi);

end

% Find and store the x and y coordinates of all Gauss points
for lmn = 1:nelem

    lmncoord = zeros(ncoord,maxnodes);
    % Extract nodal coordinates for the current element
    for a = 1:nelnodes(lmn)
        for i = 1:ncoord
            lmncoord(i,a) = coords(i,connect(a,lmn));
        end
    end

    % Transpose lmncoord (from 2x4 to 4x2)
    lmncoord_transp = lmncoord';
    % Calculate the x and y coordinates of the Gauss points
    xcoord_GP_mat(lmn,:) = N' * lmncoord_transp(:,1);
    ycoord_GP_mat(lmn,:) = N' * lmncoord_transp(:,2);

end

% % Identify the position IDs of different nodes based on different
% % classifications
[ID_dofs_list_u_p,ID_dofs_list_u_f,ID_dofs_list_nl_strain,ID_dofs_list_disp,ID_dofs_list_x,ID_dofs_list_y,ID_free_nodes_e,ID_prescribed_nodes_e] = func_find_dof_IDs(fixnodes,ndof,dofs_stored,SolverID);

ArcLength_update_switch = 0;
failed_attempt_counter  = 0;

% Identify the elements on the buffer plates (for the 4 point bending
% problem only)

% Extract coords of nodes, DOF for the current element

counter_node_set     = 1;
counter_set          = 1;
Node_stiff_set       = zeros;
ID_element_stiff_set = zeros;

if model_name == '4PB_notch50' || model_name == 'L_shaped_v1' || model_name == 'L_shaped_v2' || model_name == 'L_shaped_v3'

    for i = 1 : 1 : size(coords,2)
        condition1 = (coords(1,i) >= 450) || (coords(2,i) <= 50);
        if condition1
            Node_stiff_set(counter_node_set, 1) = i;
            counter_node_set = counter_node_set + 1;
        end
    end

    for i = 1 : 1 : lmn
        if any(ismember(connect(:,i), Node_stiff_set))
            ID_element_stiff_set(counter_set,1) = i;
            counter_set = counter_set + 1;
        end
    end

else
    ID_element_stiff_set = [];
end


if model_name == 'Test_slab_v2'

    for i = 1 : 1 : size(coords,2)
        condition1 = (coords(1,i) <= 17.5 && coords(1,i) >= 16.5);
        if condition1
            Node_stiff_set(counter_node_set, 1) = i;
            counter_node_set = counter_node_set + 1;
        end
    end

    for i = 1 : 1 : lmn
        if any(ismember(connect(:,i), Node_stiff_set))
            ID_element_stiff_set(counter_set,1) = i;
            counter_set = counter_set + 1;
        end
    end

else
    ID_element_stiff_set = [];
end

if model_name == 'Brazilian_v1'

    for i = 1 : 1 : size(coords,2)
        condition1 = (coords(1,i) <= 1 && coords(2,i) >= 20);
        if condition1
            Node_stiff_set(counter_node_set, 1) = i;
            counter_node_set = counter_node_set + 1;
        end
    end

    for i = 1 : 1 : lmn
        if any(ismember(connect(:,i), Node_stiff_set))
            ID_element_stiff_set(counter_set,1) = i;
            counter_set = counter_set + 1;
        end
    end

else
    ID_element_stiff_set = [];
end


storage_reactions = zeros(2,6);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ======================== RELOAD SAVED DATA FILE =========================
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% cd (save_path); reload_file_name=sprintf('Reload');
% load(reload_file_name);
% 
% % Enter location of current file path
% main_file_path='C:\Users\rs7625\Desktop\Calibration algorithm (21st October 2024)';
% 
% sf                ='\Saved Files';
% ps                ='\Perm Storage';
% im                ='\Images';
% 
% save_path         = strcat(main_file_path,sf);
% perm_storage_path = strcat(main_file_path,ps);
% image_storage_path = strcat(main_file_path,im);
% 
% cd (main_file_path);
% 
% f = figure('Visible', 'on');
% plot(plot_storage(:,1),plot_storage(:,2))
% xlabel('Displacement (mm)')
% ylabel('Force (N)')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ============================ UAL ANALYSIS ===============================
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initially set the residual above the tolerance to start the analysis
residual_norm=2*(tolerance);

disp("alpha_val = " + num2str(alpha_val))
disp("beta_val  = " + num2str(beta_val ))
disp("e_delta   = " + num2str(e_delta  ))
disp("lc        = " + num2str(lc       ))

% disp("Localizing gradient paramters")
% disp("e_i        = " + num2str(e_i     ))
% disp("e_delta    = " + num2str(e_delta ))
% disp("e_f        = " + num2str(e_f     ))


global_storage_residual_components = zeros(30,12,10);
res_comp_counter            = 0; 

if RoutineID == 1

    % Calculate the reference dof to measure the displacement applied at each increment
    [~, ref] = max(abs(Applied_Displacement_Load));

    while abs(u_bar_conv(ref,1)) <= abs(Applied_Displacement_Load(ref,1)) || residual_norm(end)>tolerance
        IsProj = 0;

        % Update the residual storage counter
        res_comp_counter = res_comp_counter + 1;

        % Perform the Unified Arclength analysis
        [storage_residual_components, storage_reactions, convergance_flag,delta_e_nl_conv,e_nl_conv,delta_m_bar,increment,J, dofs, residual_norm, g_constraint,Res_F_E_rct,Res_F_F,last_iteration, history_var_mat_conv, strain_var_mat_conv, ~, ~,Reactions_x,Reactions_y,Reactions_total,delta_m_bar_conv,delta_u_bar_conv,delta_u_f_conv,delta_f_rct_disp_ebc_conv,m_bar_conv,u_bar_conv,u_f_conv,f_rct_disp_ebc_conv,ArcLength,Load_percentage_last_saved,history_localizing_gradient_g_conv,history_localizing_gradient_nle_conv] = func_UnifiedArcLength_DispControl(model_name,g_constraint,Res_F_E_rct,Res_F_F,Constraint_type,strain_var_mat_conv,tolerance,Load_percentage_last_saved,main_file_path,save_path,ArcLength_0,Applied_Displacement_Load,delta_m_bar_conv,delta_u_bar_conv,delta_u_f_conv,delta_f_rct_disp_ebc_conv,m_bar_conv,u_bar_conv,u_f_conv,f_rct_disp_ebc_conv,ArcLength,delta_m_bar_0,dofs,fixnodes,increment,Delastic,history_var_mat_conv,num_elem_at_node,n_hood,weights,Scheme_ID,strain_tolerance,IsProj,RoutineID,delta_m_bar,ID_dofs_list_u_p,ID_dofs_list_u_f,ID_dofs_list_nl_strain,ID_dofs_list_disp,ID_free_nodes_e,ID_prescribed_nodes_e,delta_e_nl_conv,e_nl_conv, ID_element_stiff_set, storage_reactions);

        % -----------------------------------------------------------------
        % ------------ SAVING AND ADAPTIVE ARCLENGTH ROUTINE --------------
        % -----------------------------------------------------------------

        % Store the residual components
        global_storage_residual_components(:,:,res_comp_counter) = storage_residual_components;

        % Calculate the number of failed tries
        if convergance_flag == 1
            % Reset failed attempt counter
            failed_attempt_counter = 0;
        else
            failed_attempt_counter = failed_attempt_counter + 1;
        end

        % Save convergred increments
        if residual_norm(1,end)<tolerance
            % Assign Force Displacement plot values
            if model_name =='Test_slab' || model_name =='Test_slab_snapback' || model_name =='Test_slab_v2'
                save_disp = abs(u_bar_conv(ref,1)) * 2;
                save_force = Reactions_x;
            elseif model_name == 'Hasanzadeh_coarse' || model_name == 'Hasanzadeh_fine' || model_name == 'Hasanzadeh_coarse_right_end_fixed' || model_name == 'Hasanzadeh_fine_right_end_fixed' || model_name == 'Hasanzadeh_interm_1' || model_name == 'Hasanzadeh_interm_2'
                save_disp = abs(u_bar_conv(ref,1));
                save_force = Reactions_y * 140;        % Accounting for plane strain condition
            elseif model_name == 'Hasanzadeh_half_interm_1'  || model_name == 'Hasanzadeh_half_interm_2' || model_name == 'Hasanzadeh_half_lc_2' || model_name == 'Hasanzadeh_half_lc_1.5' || model_name == 'Hasanzadeh_half_lc_1.25' || model_name == 'Hasanzadeh_half_lc_1'  || model_name == 'Hasanzadeh_half_lc_0.75' || model_name == 'Hasanzadeh_half_lc_0.5'
                save_disp = abs(u_bar_conv(ref,1));
                save_force = Reactions_y * 70;         % Accounting for plane strain condition
            elseif model_name == 'DNT_Hz_lc_1.5' || model_name == 'DNT_Hz_lc_2.2'
                save_disp = abs(u_bar_conv(ref,1));
                save_force = Reactions_y * 50 * 2 * 2; % Accounting for plane strain condition
            elseif model_name == '4PB_notch50'
                save_disp      = abs(u_bar_conv(ref,1));
                save_force     = Reactions_y;         % Accounting for loading condition
                save_test_disp = abs(dofs(FPB_ref_dof,1));   % Measuring displacement at a point 7.5 mm (node number 11) from the mid point at the bottom surface (to maintain consistency with experimental data)
                save_force_total = Reactions_total;
            elseif model_name == 'L_shaped_v1' || model_name == 'L_shaped_v2' || model_name == 'L_shaped_v3'
                save_disp      = abs(u_bar_conv(ref,1));
                save_force     = Reactions_total * 100;         % Accounting for plane strain condition
            elseif model_name =='Brazilian_v1' || model_name =='Brazilian_v2' || model_name =='Brazilian_v3' || model_name =='Brazilian_v4' || model_name =='Brazilian_v5' || model_name =='Brazilian_v6' || model_name =='Brazilian_v7' || model_name =='Brazilian_v8' || model_name =='Brazilian_v9' || model_name =='Brazilian_v10' || model_name =='Brazilian_v11'
                save_disp = abs(u_bar_conv(ref,1));
                save_force = Reactions_y; % Accounting for plane strain condition
            else
                save_disp = abs(u_bar_conv(ref,1));
                save_force = Reactions_y;
            end
            storage_localizing_gradient_g_conv(:,:,increment)   = history_localizing_gradient_g_conv;
            storage_localizing_gradient_nle_conv(:,:,increment) = history_localizing_gradient_nle_conv;
            plot_storage(increment+1,1) = save_disp;
            plot_storage(increment+1,2) = save_force;
            plot_storage(increment+1,3) = Reactions_x;
            plot_storage(increment+1,4) = Reactions_total;

            % Update increment
            increment=increment+1;

            % Save converged variables for the current iteration
            format shortg
            Load_percentage = round(((u_bar_conv(ref,1)/Applied_Displacement_Load(ref,1))*100),4);
            file_name       = sprintf('Increment = %d, Load percentage = %.3f .mat',increment-1,Load_percentage);
            Load_percentage_last_saved = Load_percentage;
            cd (save_path)
            save (file_name)
            cd (main_file_path)
            format compact

            % Update ArcLength
            if last_iteration<5
                ArcLength = min(ArcLength_upper_limit,(10^(log10(ArcLength)+0.2)));
            elseif last_iteration>12
                ArcLength = max(ArcLength_lower_limit,(10^(log10(ArcLength)-0.2)));
            end

            % ========================== Plotting damage contours =================================
            if plot_switch == 1
                IsProj = 1;
                [~,~,~,~,~,~,~,~, ~, ~, ~,~,~,~, ~, ~,gausspoints_prop_mat, nodes_prop_mat,~,~,~,~,~,~,~,~,~,~,~,~,~,~,~] = func_UnifiedArcLength_DispControl(model_name,g_constraint,Res_F_E_rct,Res_F_F,Constraint_type,strain_var_mat_conv,tolerance,Load_percentage_last_saved,main_file_path,save_path,ArcLength_0,Applied_Displacement_Load,delta_m_bar_conv,delta_u_bar_conv,delta_u_f_conv,delta_f_rct_disp_ebc_conv,m_bar_conv,u_bar_conv,u_f_conv,f_rct_disp_ebc_conv,ArcLength,delta_m_bar_0,dofs,fixnodes,increment,Delastic,history_var_mat_conv,num_elem_at_node,n_hood,weights,Scheme_ID,strain_tolerance,IsProj,RoutineID,delta_m_bar,ID_dofs_list_u_p,ID_dofs_list_u_f,ID_dofs_list_nl_strain,ID_dofs_list_disp,ID_free_nodes_e,ID_prescribed_nodes_e,delta_e_nl_conv,e_nl_conv, ID_element_stiff_set,storage_reactions);

                max_damage          = max(gausspoints_prop_mat(:,1));
                max_nl_shear_strain = max(gausspoints_prop_mat(:,12));
                func_plotmesh2(ID_element_stiff_set, save_disp, main_file_path,image_storage_path,coords,connect,nelem,nodes_prop_mat(:,1),nodes_prop_mat(:,8),nodes_prop_mat(:,9),nodes_prop_mat(:,10), nodes_prop_mat(:,11),nodes_prop_mat(:,12),nelnodes,'interp',model_name,inc_success_counter,last_iteration,increment,loadfactor,solver_string,tangent_string,SolverID,ID_dofs_list_x,ID_dofs_list_y,dofs,Load_percentage,RoutineID,nodes_prop_mat(:,5),nodes_prop_mat(:,6),nodes_prop_mat(:,7));
            end
            % ===================================================================================

        else
            % Update ArcLength
            if model_name == 'Test_slab' || model_name =='Test_slab_snapback'                                                           
                ArcLength = min(20*ArcLength_upper_limit,(10^(log10(ArcLength)+0.2)));
            elseif model_name == 'Hasanzadeh_coarse' || model_name == 'Hasanzadeh_fine' || model_name == 'Hasanzadeh_coarse_right_end_fixed' || model_name == 'Hasanzadeh_fine_right_end_fixed' || model_name == 'Hasanzadeh_interm_1' || model_name == 'Hasanzadeh_interm_2' || model_name == 'Hasanzadeh_half_interm_2' || model_name == 'Hasanzadeh_half_interm_1' || model_name == 'Hasanzadeh_half_lc_2' || model_name == 'Hasanzadeh_half_lc_1.5' || model_name == 'Hasanzadeh_half_lc_1.25' || model_name == 'Hasanzadeh_half_lc_1'  || model_name == 'Hasanzadeh_half_lc_0.75' || model_name == 'Hasanzadeh_half_lc_0.5' || model_name == 'DNT_Hz_lc_1.5' || model_name == 'DNT_Hz_lc_2.2' || model_name == 'L_shaped_v1' || model_name == 'L_shaped_v2' || model_name == 'L_shaped_v3' || model_name =='Test_slab_v2' || model_name == 'Brazilian_v1' 
                if ArcLength <= 1e-3
                    ArcLength_update_switch = 1;
                    if ArcLength_update_switch == 1
                        ArcLength = min(20*ArcLength_upper_limit,(10^(log10(ArcLength)+0.2)));
                    elseif ArcLength_update_switch == 0
                        ArcLength = max(ArcLength_lower_limit,(10^(log10(ArcLength)-0.2)));
                    end
                elseif ArcLength_update_switch == 1
                    ArcLength = min(20*ArcLength_upper_limit,(10^(log10(ArcLength)+0.2)));
                else
                    ArcLength = max(ArcLength_lower_limit,(10^(log10(ArcLength)-0.2)));
                end
            elseif model_name == '4PB_notch50' 
                if ArcLength <= 1e-5
                    ArcLength_update_switch = 1;
                    if ArcLength_update_switch == 1
                        ArcLength = min(20*ArcLength_upper_limit,(10^(log10(ArcLength)+0.2)));
                    elseif ArcLength_update_switch == 0
                        ArcLength = max(ArcLength_lower_limit,(10^(log10(ArcLength)-0.2)));
                    end
                elseif ArcLength_update_switch == 1
                    ArcLength = min(20*ArcLength_upper_limit,(10^(log10(ArcLength)+0.2)));
                else
                    ArcLength = max(ArcLength_lower_limit,(10^(log10(ArcLength)-0.2)));
                end
            else 
                ArcLength = max(ArcLength_lower_limit,(10^(log10(ArcLength)-0.2)));
            end
        end

        %==================================================================================
        %============================== Detect a bad attempt ==============================
        %==================================================================================

        % Case 1: Force-displacement doesn't make sense

        % Exit if the ArcLength reaches the lower limit or you get -ve
        % force (which is an indication of extreme backtracking)

        if ArcLength <= ArcLength_lower_limit || (u_bar_conv(ref,1)) < 0 || plot_storage(end,2) < 0
            % ============================= Exit the matlab function ==============================
            % Export the force-displacement curve
            MATLAB_OP = plot_storage;

            % Store data from the current run into the permanent storage folder
            format shortg
            file_name = sprintf('Attempt %d .mat',num_function_calls);
            cd (perm_storage_path)
            save (file_name)
            cd (main_file_path)
            format compact

            if plot_switch == 0
                % Delete the saved files from this run
                directory = save_path; % Specify the directory
                files = dir(fullfile(directory, '*')); % Get a list of all files in the directory

                for i = 1:numel(files)
                    if ~files(i).isdir % Check if it's not a directory
                        delete(fullfile(directory, files(i).name)); % Delete the file
                    end
                end
            end
            % =====================================================================================

            return

            % Case 2: Too many failed attempts

        elseif failed_attempt_counter >= 20
            % ============================= Exit the matlab function ==============================
            % Export the force-displacement curve
            MATLAB_OP = plot_storage;

            % Store data from the current run into the permanent storage folder
            format shortg
            file_name = sprintf('Attempt %d .mat',num_function_calls);
            cd (perm_storage_path)
            save (file_name)
            cd (main_file_path)
            format compact


            if plot_switch == 0
                % Delete the saved files from this run
                directory = save_path; % Specify the directory
                files = dir(fullfile(directory, '*')); % Get a list of all files in the directory

                for i = 1:numel(files)
                    if ~files(i).isdir % Check if it's not a directory
                        delete(fullfile(directory, files(i).name)); % Delete the file
                    end
                end
            end
            % =====================================================================================

            return
        end
        %==================================================================================
       
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    % ============================= Exit the matlab function ==============================
    % Export the force-displacement curve
    MATLAB_OP = plot_storage;

    % Store data from the current run into the permanent storage folder
    format shortg
    file_name = sprintf('Attempt %d .mat',num_function_calls);
    cd (perm_storage_path)
    save (file_name)
    cd (main_file_path)
    format compact


    if plot_switch == 0
        % Delete the saved files from this run
        directory = save_path; % Specify the directory
        files = dir(fullfile(directory, '*')); % Get a list of all files in the directory

        for i = 1:numel(files)
            if ~files(i).isdir % Check if it's not a directory
                delete(fullfile(directory, files(i).name)); % Delete the file
            end
        end
    end
    % =====================================================================================

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ======================= NEWTON - RAPHSON ANALYSIS =======================
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if RoutineID == 2

    % Calculate the reference dof to measure the displacement applied at each increment
    [ref, ref_node_ID, ref_node_pos] = finc_identify_ref(fixnodes, ndof, model_name);

    while loadfactor <= 1 && countflaglf == 0 && incrflag < 20

        % Condition to terminate the while loop: the total load is applied
        if flaglf == true; countflaglf = 1; end

        % Condition to terminate the while loop: dlfactor is too small
        if dlfactor < 10^-30; break; end

        IsProj = 0;

        % Perform the Newton Raphson analysis
        [J, dofs, Res_F_F_norm, Res_u_norm, last_iteration, history_var_mat, ~, ~, Reactions_x, Reactions_y, Reactions_total, storage_reactions] = func_NewtonRaphson_DispControl(ID_element_stiff_set, model_name,RoutineID,dofs_stored,[fixnodes(1:2,:); fixnodes(3,:)*loadfactor],increment,Delastic,history_var_mat_stored,num_elem_at_node,n_hood,weights,tolerance,IsProj);

        % ---------------------------------------------------------------------
        % ------------------------ ADAPT LOAD ROUTINE -------------------------
        % ---------------------------------------------------------------------

        % Adapt load incrementation w.r.t. the number of iterations needed for convergence
        if last_iteration <= min_iter
            % Fast Convergence - dlfactor increases
            [dofs_stored,loadfactor_stored,history_var_mat_stored,incrflag,flagplot,loadfactor,increment, ...
                inc_success_counter,flaglf,dlfactor] = func_adapt_quick_convergence(dofs,loadfactor,history_var_mat,last_iteration,dlfactor,increment,inc_success_counter);

        elseif (min_iter < last_iteration) && (last_iteration <= max_iter)
            % Moderate Convergence - dlfactor remains the same
            [dofs_stored,loadfactor_stored,history_var_mat_stored,incrflag,flagplot,loadfactor,increment, ...
                inc_success_counter,flaglf] = func_adapt_moderate_convergence(dofs,loadfactor,history_var_mat,dlfactor,increment,inc_success_counter);

        elseif (max_iter < last_iteration) && (last_iteration < max_accept_iter)
            % Slow Convergence - dlfactor decreases
            [dofs_stored,loadfactor_stored,history_var_mat_stored,incrflag,flagplot,loadfactor,increment, ...
                inc_success_counter,flaglf,dlfactor] = func_adapt_slow_convergence(dofs,loadfactor,history_var_mat,last_iteration,dlfactor,increment,inc_success_counter);

        else
            % No Convergence - discard the last step and repeat with smaller load value
            [flagplot,flaglf,countflaglf,incrflag,loadfactor,dlfactor] = func_adapt_no_convergence(incrflag,loadfactor_stored,dlfactor);

        end

        % -----------------------------------------------------------------
        % ----------------------- SAVING ROUTINE --------------------------
        % -----------------------------------------------------------------

        % Save convergred increments
        if Res_u_norm(1,end)<tolerance
            % Assign Force Displacement plot values
            if model_name =='Test_slab' || model_name =='Test_slab_snapback' || model_name =='Test_slab_v2'
                save_disp = abs(dofs_stored(ref,1)) * 2;
                save_force = Reactions_x;
            elseif model_name == 'Hasanzadeh_coarse' || model_name == 'Hasanzadeh_fine' || model_name == 'Hasanzadeh_coarse_right_end_fixed' || model_name == 'Hasanzadeh_fine_right_end_fixed' || model_name == 'Hasanzadeh_interm_1' || model_name == 'Hasanzadeh_interm_2'
                save_disp = abs(dofs_stored(ref,1));
                save_force = Reactions_y * 140;        % Accounting for plane strain condition
            elseif model_name == 'Hasanzadeh_half_interm_1'  || model_name == 'Hasanzadeh_half_interm_2' || model_name == 'Hasanzadeh_half_lc_2' || model_name == 'Hasanzadeh_half_lc_1.5' || model_name == 'Hasanzadeh_half_lc_1.25' || model_name == 'Hasanzadeh_half_lc_1'  || model_name == 'Hasanzadeh_half_lc_0.75' || model_name == 'Hasanzadeh_half_lc_0.5'
                save_disp = abs(dofs_stored(ref,1));
                save_force = Reactions_y * 70;         % Accounting for plane strain condition
            elseif model_name == 'DNT_Hz_lc_1.5' || model_name == 'DNT_Hz_lc_2.2'
                save_disp = abs(dofs_stored(ref,1));
                save_force = Reactions_y * 50 * 2 * 2; % Accounting for plane strain condition
            elseif model_name == '4PB_notch50'
                save_disp = abs(u_bar_conv(ref,1));
                save_force = Reactions_y * 50; % Accounting for plane strain condition
            elseif model_name == 'L_shaped_v1' || model_name == 'L_shaped_v2' || model_name == 'L_shaped_v3'
                save_disp      = abs(dofs_stored(ref,1));
                save_force     = Reactions_total * 100;         % Accounting for plane strain condition
            elseif model_name =='Brazilian_v1' || model_name =='Brazilian_v2' || model_name =='Brazilian_v3' || model_name =='Brazilian_v4' || model_name =='Brazilian_v5' || model_name =='Brazilian_v6' || model_name =='Brazilian_v7' || model_name =='Brazilian_v8' || model_name =='Brazilian_v9' || model_name =='Brazilian_v10' || model_name =='Brazilian_v11'
                save_disp = abs(dofs_stored(ref,1));
                save_force = Reactions_y; % Accounting for plane strain condition
            else
                save_disp = abs(dofs_stored(ref,1));
                save_force = Reactions_y;
            end

            plot_storage(increment,1) = save_disp;
            plot_storage(increment,2) = save_force;

            if plot_switch == 1
                IsProj = 1;

                [~, ~, ~, ~, ~, ~, gausspoints_prop_mat, nodes_prop_mat, ~, ~, ~, ~] = func_NewtonRaphson_DispControl(ID_element_stiff_set, model_name, RoutineID, dofs, [fixnodes(1:2,:); fixnodes(3,:)*loadfactor], increment, Delastic, history_var_mat_stored, num_elem_at_node, n_hood, weights, tolerance, IsProj);
                max_damage = max(gausspoints_prop_mat(:,1));

                func_plotmesh2(ID_element_stiff_set, save_disp, main_file_path,image_storage_path,coords,connect,nelem,nodes_prop_mat(:,1),nodes_prop_mat(:,8),nodes_prop_mat(:,9),nodes_prop_mat(:,10), nodes_prop_mat(:,11),nodes_prop_mat(:,12),nelnodes,'interp',model_name,inc_success_counter,last_iteration,increment,loadfactor,solver_string,tangent_string,SolverID,ID_dofs_list_x,ID_dofs_list_y,dofs,[],RoutineID,nodes_prop_mat(:,5),nodes_prop_mat(:,6),nodes_prop_mat(:,7));

            end

            % Save converged variables for the current iteration
            format shortg
            Load_percentage=round(((dofs(ref,1)/fixnodes(3,ref_node_pos))*100),4);
            file_name=sprintf('Increment = %d, Load percentage = %.3f .mat',increment-1,Load_percentage);
            Load_percentage_last_saved=Load_percentage;
            cd (save_path)
            save (file_name)
            cd (main_file_path)
            format compact

        end

    end
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Export the force-displacement curve
    MATLAB_OP = plot_storage;

    % Store data from the current run into the permanent storage folder
    format shortg
    file_name = sprintf('Attempt %d .mat',num_function_calls);
    cd (perm_storage_path)
    save (file_name)
    cd (main_file_path)
    format compact

    if plot_switch == 0
        % Delete the saved files from this run
        directory = save_path; % Specify the directory
        files = dir(fullfile(directory, '*')); % Get a list of all files in the directory

        for i = 1:numel(files)
            if ~files(i).isdir % Check if it's not a directory
                delete(fullfile(directory, files(i).name)); % Delete the file
            end
        end
    end

end

end