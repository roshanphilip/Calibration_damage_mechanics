#=================================================================================
#---------------------------- CALIBRATION MAIN SCRIPT ----------------------------
#=================================================================================
# Ref: R.P. Saji, P. Pantidis,L. Svolos, M. Mobasher, Multi-stage calibration framework for continuum damage mechanics models 
# Journal: Computational Mechanics [doi:10.1007/s00466-024-02473-5]
# Author 1: Dr. Roshan Philip Saji
# # email: rs7625@nyu.edu
# Author 2: Dr. Panos Pantidis
# email: pp2624@nyu.edu
# Author 3: Prof. Lampros Svolos
# email: Lampros.Svolos@uvm.edu
# Author 4: Prof. Mostafa Mobasher 
# email: mostafa.mobasher@nyu.edu
#
# Computational Solid Mechanics Lab, New York University Abu Dhabi
# Department of Civil and Environmental Engineering, University of Vermont, Burlington, VT, USA
# Date: 03-July-2025 
# Link to manuscript: [https://doi.org/10.1016/j.engfracmech.2025.111341]
#=================================================================================
""""
Checklist before running code:
1. Ensure that you are using the correct anaconda environment 
2. The reference data should be in a file named Ref_data_modelname.xlsx in the main file path 
3. Ensure the applied displacement (Applied_disp) corresponds to the problem you are calibrating
4. If you choose to use a truncated version of the reference graph or a special case (like snapback), reflect that in the excel file name and path (ref_excel_file_path)
5. Update the solver specific parameters in func_MATLAB_loss_function_UAL based on your requirements
6. Enter reasonable initial guesses of your parameters based on the relevant literature
7. Enter reasonable bounds for your parameters for each optimization stage for efficient calibration 
"""
#=================================================================================
#-------------------------------- INITIALIZATION ---------------------------------
#=================================================================================
import sys

# Define the expected path to the correct Python interpreter
expected_interpreter = r'c:\Users\rs7625\AppData\Local\anaconda3\envs\tf_calibration_project_1\python.exe'

# Check if the current interpreter matches the expected one
if sys.executable != expected_interpreter:
    print(f"Warning: You are not using the correct Python interpreter!")
    print(f"Expected: {expected_interpreter}")
    print(f"Current: {sys.executable}")
    print("Please activate the correct Anaconda environment.")
    exit()

import matlab.engine
import numpy as np
from scipy.optimize import minimize, shgo
from scipy.interpolate import interp1d
import time
import csv
import pandas as pd

# Measure start time
start_time = time.time()

# Start a MATLAB session
eng = matlab.engine.start_matlab()

# Array to store the elapsed times for each MATLAB function call
elapsed_times = []

# Counter for the number of function calls
num_function_calls = 0

# List to store the history of num_function_calls and sum_loss
loss_history = []

# Variable to store the current loss
"""
We start at infinity as it then ensures that any loss will be lower than
this and this is likely to give a more accurate guess of the 'x' parameters
"""
current_loss = float('inf')  

#=================================================================================
#---------------------------------- USER INPUTS ----------------------------------
#=================================================================================

# Enter the MATLAB function file path
model_name           = r'Test_slab'
matlab_function_path = r'C:\Users\rs7625\Desktop\Calibration framework package\Calibration code'

ref_excel_file_path  = matlab_function_path + r'\Ref_data_' + model_name  + r'.xlsx'

# Choose if you want to run a test problem (simple algebraic equation; used when testing new features in the script)
test_or_not = 0 # 0 - UAL algorithm  1 - Test problem (Debugging mode)

# Enter the type of optimization algorithm you want 
opt_type = 1   # 1 - Nelder-Mead    2 - L-BFGS-B    3 -S BFGS    4 - SHGO

# Enter if you want to optimize all parameters simultaneously or not 
opt_trigger = 1      # 0 - Optimize all parameters simultaneously      1 - Optimize for e_star first, followed by a and b

# Threshold
# A_1] Threshold for stopping the optimization (If opt_trigger = 0)
loss_threshold = 0.03                             # If opt_trigger = 0

# A_2] Global threshold for stopping the optimization (If opt_trigger = 1)
opt_threshold_global = 0.12

# B] Enter the loss threshold for the three optimization steps (If opt_trigger = 1)
opt_threshold_array = np.array([0.12, 0.12, 0.12, 0.12]) # If opt_trigger = 1

# Enter the value of maximum applied displacement 
Applied_disp = 0.05

# Initial guess for the parameters
a_guess      = np.array([0.1])
b_guess      = np.array([1200])
e_star_guess = np.array([2.25e-4])
lc_guess     = np.array([12])

# Enter the bounds of the parameters at the different optimization steps 

# 0. Optimization 0
bounds_opt_0 = [(1e-6, 1e-3)]                  # bounds for e_star

# A. Optimization 1
bounds_opt_1 = [(10, 15000),(1e-6, 1e-3)]    # bounds for b and e_star

# B. Optimization 2
bounds_opt_2 = [(0.01, 1),(10, 15000)]        # bounds for a and b

# C. Optimization 3
bounds_opt_3 = [(0.01, 1),(10, 15000)]        # bounds for a and b

#=================================================================================
#------------------------- CALCULATE REF LOSS FUNCTIONS --------------------------
#=================================================================================

"""
F1_a - Max. force value 
F1_b - Value of displacement at max. force
F2   - Area under the force-displacement curve 
F3   - The force history vector of the reference 
"""

# Calculate the reference loss function values
ref_disp_pd  = pd.read_excel(ref_excel_file_path, usecols=[0])
ref_force_pd = pd.read_excel(ref_excel_file_path, usecols=[1])

ref_disp = ref_disp_pd.to_numpy()
ref_force = ref_force_pd.to_numpy()
ref_curve = np.hstack((ref_disp, ref_force))

F0   = np.max(ref_force)
F1_a = np.max(ref_force)
indices = np.argmax(ref_force)
F1_b = ref_disp[indices,0]

F2 = float(np.trapz(ref_force, x=ref_disp, axis=0))   # This assumes that the inputs are column vectors
F3 = ref_force

#=================================================================================
#----------------------------- FUNCTION DEFINITIONS ------------------------------
#=================================================================================

#---------------------------------------------------------------------------------
# Function 1: Matlab loss function
# This function calculates the value of the loss function based on the output from the UAL algorithm
# Input: Guess of x, No. of attempts
# Output: Weighted sum of the loss function array

def matlab_loss_function(x):
   
    global num_function_calls, current_loss, loss_history, current_guess, initial_OP, final_OP, ref_curve, e_star_guess_1, opt_seq, opt_trigger, a_guess_2, b_guess_2, lc_guess_2, a_guess_1, b_guess_1, e_star_guess_0  # Use the global variable

    # Assign a value to the current guess of the input parameters 
    if opt_trigger == 0:
        current_guess = x
    elif opt_trigger == 1 and opt_seq == 0:
        current_guess = np.concatenate((a_guess.flatten(), b_guess.flatten(),x[0].flatten(), lc_guess.flatten(), [0]), axis=0).reshape(1, 5)
    elif opt_trigger == 1 and opt_seq == 1:
        current_guess = np.concatenate((a_guess.flatten(), x[0].flatten(),x[1].flatten(), lc_guess.flatten(), [0]), axis=0).reshape(1, 5)
    elif opt_trigger == 1 and (opt_seq == 2):
        current_guess = np.concatenate((x[0].flatten(), x[1].flatten(), e_star_guess_1.flatten(), lc_guess.flatten(), [0])).reshape(1, 5)
    elif opt_trigger == 1 and (opt_seq == 3):
        current_guess = np.concatenate((x[0].flatten(), x[1].flatten(), e_star_guess_1.flatten(), lc_guess.flatten(), [0])).reshape(1, 5)

    # Increment the function call counter
    num_function_calls += 1

    # Add the directory containing loss_function.m to MATLAB path
    eng.addpath(matlab_function_path, nargout=0)

    # Convert x to MATLAB double array
    x_matlab = matlab.double(current_guess)
    
    # Measure start time for this function call
    call_start_time = time.time()
    
    # Log the start of the function call
    # print(f"[{time.ctime()}] Calling MATLAB function with x = {x.tolist()}")
    
    # Call the MATLAB function
    if test_or_not == 0:
         MATLAB_OP = eng.func_MATLAB_loss_function_UAL(x_matlab, num_function_calls, matlab_function_path, model_name) 
         # Convert the MATLAB output to a numpy array
         MATLAB_OP = np.array(MATLAB_OP) 

         # Store the initial guess
         if num_function_calls == 1:
             initial_OP = MATLAB_OP

         # Extract displacement and force
         displacement = MATLAB_OP[:, 0]
         force = MATLAB_OP[:, 1]

         # If the UAL output goes beyond the applied displacement, interpolate the last entries based on applied displacement
         if MATLAB_OP[-1, 0] > Applied_disp:
            # Interpolate the target curve based on the reference curve displacement
            cutoff_displacement         = Applied_disp
            interpolation_function_test = interp1d(displacement, force, kind='linear', fill_value="extrapolate")
            cutoff_force                = interpolation_function_test(cutoff_displacement)

            # Enter the interpolated cutoff force and displacement values 
            MATLAB_OP[-1, 0] = cutoff_displacement
            MATLAB_OP[-1, 1] = cutoff_force

         # Check if the total loss is less than the global threshold
         trip_wire(MATLAB_OP)

         # Calculate the loss values from the force-displacement data from MATLAB
         # G1: Peak force (predicted)
         # G2: Area under the curve (predicted)
         # G3: Force (predicted)

         if n_loss_functions == 0:
             G0          = np.max(MATLAB_OP[:, 1])
             O0          = np.sqrt(((F0 - G0) / F0) ** 2)
              
             loss_components = [O0] 
   
         elif n_loss_functions == 1:      
             G0          = np.max(MATLAB_OP[:, 1])

             G1_a        = np.max(MATLAB_OP[:, 1])
             indices_max = np.argmax(MATLAB_OP[:, 1])
             G1_b        = MATLAB_OP[indices_max,0]

             # Calculate the loss function components
             O0          = np.sqrt(((F0 - G0) / F0) ** 2)
             
             O1_a        = (((F1_a - G1_a) / F1_a) ** 2)
             O1_b        = (((F1_b - G1_b) / F1_b) ** 2)
       
             O1          = np.sqrt((O1_a) + (O1_b))

             loss_components = [O0, O1] 

         elif n_loss_functions == 2:            
             G0          = np.max(MATLAB_OP[:, 1])

             G1_a        = np.max(MATLAB_OP[:, 1])
             indices_max = np.argmax(MATLAB_OP[:, 1])
             G1_b        = MATLAB_OP[indices_max,0]

             G2          = np.trapz(force, x=displacement)

             # Calculate the loss function components
             O1_a        = (((F1_a - G1_a) / F1_a) ** 2)
             O1_b        = (((F1_b - G1_b) / F1_b) ** 2)

             O0          = np.sqrt(((F0 - G0) / F0) ** 2)
       
             O1          = np.sqrt((O1_a) + (O1_b))
             O2          = np.sqrt(((F2 - G2) / F2) ** 2)

             loss_components = [O0, O1 , O2]   

         elif n_loss_functions == 3:
             G0          = np.max(MATLAB_OP[:, 1])

             G1_a        = np.max(MATLAB_OP[:, 1])
             indices_max = np.argmax(MATLAB_OP[:, 1])
             G1_b        = MATLAB_OP[indices_max,0]

             G2          = np.trapz(force, x=displacement)
             OA3, G3     = calculate_l2_norm(ref_curve, MATLAB_OP) # OA3 is the L2 norm between the reference and predicted force (iterpolated and normalized) vectors

            # Calculate the loss function components
             O1_a        = (((F1_a - G1_a) / F1_a) ** 2)
             O1_b        = (((F1_b - G1_b) / F1_b) ** 2)
            
             O0          = np.sqrt(((F0 - G0) / F0) ** 2)
             O1          = np.sqrt((O1_a) + (O1_b))
             O2          = np.sqrt(((F2 - G2) / F2) ** 2)
             O3          = np.sqrt((OA3/np.linalg.norm(F3)) ** 2) 

             loss_components = [O0, O1 , O2, O3]   

    elif test_or_not == 1:
         loss_components = eng.test_loss_function(x_matlab,matlab_function_path)
         # Convert the MATLAB loss output to a numpy array
         loss_components = np.array(loss_components).flatten()
     
    
    # Measure end time for this function call
    call_end_time = time.time()
    
    # Calculate elapsed time for this function call
    call_elapsed_time = call_end_time - call_start_time
    
    # Store the elapsed time in the array
    elapsed_times.append(call_elapsed_time)
    
    # Log the end of the function call
    # print(f"[{time.ctime()}] Finished MATLAB function call with elapsed time {call_elapsed_time:.4f} seconds")

    # Define weights
    if n_loss_functions == 0:
        w0 = 1
    elif n_loss_functions == 1:
        w0, w1 = 0.5, 0.5
    elif n_loss_functions == 2:
        w0, w1, w2 = 0.334, 0.334, 0.334  
    elif n_loss_functions == 3:        
        w0, w1, w2, w3 = 0.25, 0.25, 0.25, 0.25   
   
    # Calculate the sum of the loss components with weights
    if n_loss_functions == 0:
        loss_array = np.array([w0 * loss_components[0]])
    elif n_loss_functions == 1:
        loss_array = np.array([w0 * loss_components[0], w1 * loss_components[1]])
    elif n_loss_functions == 2:
        loss_array = np.array([w0 * loss_components[0], w1 * loss_components[1], w2 * loss_components[2]])
    elif n_loss_functions == 3:        
        loss_array = np.array([w0 * loss_components[0], w1 * loss_components[1], w2 * loss_components[2], w3 * loss_components[3]])

    # Calculate the sum of the loss array components 
    sum_loss = np.sum(loss_array)
    
    # Update the current loss
    current_loss = sum_loss

    # Store the current number of function calls and sum_loss in loss_history
    if n_loss_functions == 0:
        loss_history.append([num_function_calls, sum_loss, O0])
    elif n_loss_functions == 1:
        loss_history.append([num_function_calls, sum_loss, O0, O1])
    elif n_loss_functions == 2:
        loss_history.append([num_function_calls, sum_loss, O0, O1, O2])
    elif n_loss_functions == 3:        
        loss_history.append([num_function_calls, sum_loss, O0, O1, O2, O3])

    print('Loss value')
    print(loss_history[-1])

    # Print the loss value at the current attempt 
    print_loss_value()

    if opt_trigger == 0:
        if current_loss < loss_threshold:
            final_OP = MATLAB_OP
            print_results()
    elif opt_trigger == 1 and opt_seq == 0:
        if current_loss < opt_threshold:
            e_star_guess_0 = x[0]
    elif opt_trigger == 1 and opt_seq == 1:
        if current_loss < opt_threshold:
            b_guess_1      = x[0]
            e_star_guess_1 = x[1]
    elif opt_trigger == 1 and opt_seq == 2:
        if current_loss < opt_threshold:
            a_guess_2      = x[0] 
            b_guess_2      = x[1]            
    elif opt_trigger == 1 and opt_seq == 3:
        if current_loss < opt_threshold:
            final_OP = MATLAB_OP
            print_results()

    return sum_loss
#---------------------------------------------------------------------------------
# Function 2: This function interpolates the values of force (predcited) based on the reference force data and calculates the L2 norm between the 
# two curves 
# Input: Reference curve, Predicted curve 
# Output: L2 norm between the reference and predicted curve, Interpolated force values of the predicted curve w.r.t. reference curve

def calculate_l2_norm(reference_curve, target_curve):
    # Unpack the curves
    reference_displacement = reference_curve[:, 0]  
    reference_force        = reference_curve[:, 1]  

    target_displacement    = target_curve[:, 0]  
    target_force           = target_curve[:, 1]  
    
    # Interpolate the target curve based on the reference curve displacement
    interpolation_function = interp1d(target_displacement, target_force, kind='linear', fill_value="extrapolate")
    interpolated_tgt_force = interpolation_function(reference_displacement)
    
    # Calculate the L2 norm (normalized to account for the no. of entries)
    l2_norm = np.linalg.norm(reference_force - interpolated_tgt_force)
    
    return l2_norm, interpolated_tgt_force
#---------------------------------------------------------------------------------
# Function 3: Print the results and stop execution 
# This is a custom termination function that exits the optimization process when the current_loss goes below a user-defined threshold

def print_results():
    # Print the result
    print('Optimal parameters:', current_guess)
    print('Function value at optimal parameters:', current_loss)

    # Measure end time
    end_time = time.time()

    # Calculate total elapsed time
    total_elapsed_time = end_time - start_time
    print(f"Total elapsed time: {total_elapsed_time} seconds")

    # Print the number of function calls
    print('Number of MATLAB function calls:', num_function_calls)

    # Save the loss_history variable to a CSV file
    with open('loss_history.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['Function Call', 'Sum Loss'])  # Write a header row
        for entry in loss_history:
            writer.writerow(entry)

    # Save the elapsed_times variable to a CSV file
    with open('elapsed_times.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['Elapsed Time'])  # Write a header row
        for time_val in elapsed_times:
            writer.writerow([time_val])

    # Plot the force-displacement 
    eng.func_calibration_plot(initial_OP, final_OP, ref_curve, nargout=0)

    # Stop MATLAB engine
    eng.quit()

    # Stop the execution of the code
    exit()
#---------------------------------------------------------------------------------
# Function 4: Define a custom callback function to stop optimization 

def callback_check(xk):
    global optimization_result
   
    if current_loss < opt_threshold and opt_seq!=3: 
        
        optimization_result = xk  
        raise StopIteration  # Terminate the optimization

#---------------------------------------------------------------------------------  
# Function 5: Print the loss value at the current attempt
def print_loss_value():
    # Save the loss_history variable to a CSV file
    with open('loss_history.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['Function Call', 'Sum Loss'])  # Write a header row
        for entry in loss_history:
            writer.writerow(entry)

#---------------------------------------------------------------------------------  
# Function 6: Check if the total loss is below the global threshold [Trip wire]
def trip_wire(MATLAB_OP):

    displacement_t = MATLAB_OP[:, 0]
    force_t = MATLAB_OP[:, 1]

    G0_t          = np.max(MATLAB_OP[:, 1])
    G1_a_t        = np.max(MATLAB_OP[:, 1])
    indices_max_t = np.argmax(MATLAB_OP[:, 1])
    G1_b_t        = MATLAB_OP[indices_max_t,0]
    G2_t          = np.trapz(force_t, x=displacement_t)
    OA3_t, G3_t     = calculate_l2_norm(ref_curve, MATLAB_OP) # OA3 is the L2 norm between the reference and predicted force (iterpolated) vectors


    O1_a_t        = (((F1_a - G1_a_t) / F1_a) ** 2)
    O1_b_t        = (((F1_b - G1_b_t) / F1_b) ** 2)
            
    O0_t          = np.sqrt(((F0 - G0_t) / F0) ** 2)
    O1_t          = np.sqrt((O1_a_t) + (O1_b_t))
    O2_t          = np.sqrt(((F2 - G2_t) / F2) ** 2)
    O3_t          = np.sqrt((OA3_t/np.linalg.norm(F3)) ** 2) 
                    
    loss_components_t = [O0_t, O1_t , O2_t, O3_t]   
    w0, w1, w2, w3 = 0.25, 0.25, 0.25, 0.25   
    loss_array_t = np.array([w0 * loss_components_t[0], w1 * loss_components_t[1], w2 * loss_components_t[2], w3 * loss_components_t[3]])
    sum_loss_t = np.sum(loss_array_t)
    
    
    if sum_loss_t < opt_threshold_global:
            final_OP = MATLAB_OP
                       
            loss_history.append([num_function_calls, sum_loss_t, O0_t, O1_t, O2_t, O3_t])

             # Print the result
            print('Optimal parameters:', current_guess)
            print('Function value at optimal parameters:', sum_loss_t)

            # Measure end time
            end_time = time.time()

            # Calculate total elapsed time
            total_elapsed_time = end_time - start_time
            print(f"Total elapsed time: {total_elapsed_time} seconds")

            # Print the number of function calls
            print('Number of MATLAB function calls:', num_function_calls)

            # Save the loss_history variable to a CSV file
            with open('loss_history.csv', 'w', newline='') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(['Function Call', 'Sum Loss'])  # Write a header row
                for entry in loss_history:
                    writer.writerow(entry)

            # Save the elapsed_times variable to a CSV file
            with open('elapsed_times.csv', 'w', newline='') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(['Elapsed Time'])  # Write a header row
                for time_val in elapsed_times:
                    writer.writerow([time_val])

            # Plot the damage contours for the current guess 
            current_guess_t = current_guess

            current_guess[0, 4] = 1 

            # Convert x to MATLAB double array
            x_matlab_t = matlab.double(current_guess_t)

            MATLAB_OP = eng.func_MATLAB_loss_function_UAL(x_matlab_t, num_function_calls, matlab_function_path, model_name) 

            # Plot the force-displacement 
            eng.func_calibration_plot(initial_OP, final_OP, ref_curve, nargout=0)

            # Stop MATLAB engine
            eng.quit()
         
            # Stop the execution of the code 
            import os
            os._exit(1)

#=================================================================================
#--------------------------------- OPTIMIZATION ----------------------------------
#=================================================================================

#---------------------------------------------------------------------------------
# 0. Optimization call for e_star only (using O0)
n_loss_functions = 0
opt_seq          = 0
opt_threshold    = opt_threshold_array[0]
# Assign the value of e_star_guess to the initial optimization guess
x0_0             = e_star_guess


# Perform the optimization
try:
    if opt_type == 1:  
        result = minimize(matlab_loss_function, x0_0, method='Nelder-Mead', callback=callback_check, bounds=bounds_opt_0)
    elif opt_type == 2: 
        result = minimize(matlab_loss_function, x0_0, method='L-BFGS-B')
    elif opt_type == 3: 
        result = minimize(matlab_loss_function, x0_0, method='BFGS')   
except StopIteration:
    print("End of optimization 0")

#---------------------------------------------------------------------------------
# A. Optimization call for b and e_star only (using O1)
n_loss_functions = 1
opt_seq          = 1
opt_threshold    = opt_threshold_array[1]
# Assign the value of e_star_guess to the initial optimization guess
x0_1             = np.concatenate((b_guess.flatten(), e_star_guess_0.flatten()))


# Perform the optimization
try:
    if opt_type == 1:  
        result = minimize(matlab_loss_function, x0_1, method='Nelder-Mead', callback=callback_check, bounds=bounds_opt_1)
    elif opt_type == 2: 
        result = minimize(matlab_loss_function, x0_1, method='L-BFGS-B')
    elif opt_type == 3: 
        result = minimize(matlab_loss_function, x0_1, method='BFGS')   
except StopIteration:
    print("End of optimization 1")

#---------------------------------------------------------------------------------
# B. Optimization call for a and b only (using O1 and O2)

n_loss_functions = 2
opt_seq          = 2
opt_threshold    = opt_threshold_array[2]

# Assign the value of e_star_guess to the initial optimization guess
x0_2 = np.concatenate((a_guess.flatten(), b_guess_1.flatten()))

try:
    if opt_type == 1:  
        result = minimize(matlab_loss_function, x0_2, method='Nelder-Mead', callback=callback_check, bounds=bounds_opt_2)
    elif opt_type == 2: 
        result = minimize(matlab_loss_function, x0_2, method='L-BFGS-B')
    elif opt_type == 3: 
        result = minimize(matlab_loss_function, x0_2, method='BFGS')
except StopIteration:   
    print("End of optimization 2")

#---------------------------------------------------------------------------------
# C. Optimization call for a and b only (using O1, O2 and O3)
n_loss_functions = 3
opt_seq          = 3
opt_threshold    = opt_threshold_array[3]

# Assign the value of e_star_guess to the initial optimization guess
x0_3 = np.concatenate((a_guess_2.flatten(), b_guess_2.flatten()))

if opt_type == 1:  
     result = minimize(matlab_loss_function, x0_3, method='Nelder-Mead', callback=callback_check, bounds=bounds_opt_3)
elif opt_type == 2: 
    result = minimize(matlab_loss_function, x0_3, method='L-BFGS-B')
elif opt_type == 3: 
    result = minimize(matlab_loss_function, x0_3, method='BFGS')

#---------------------------------------------------------------------------------

#=================================================================================
#------------------------------------ END ----------------------------------------
#=================================================================================
