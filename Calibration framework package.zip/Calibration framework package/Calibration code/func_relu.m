function [y] = func_relu(x)
% ===================== RELU ACTIVATION FUNCTION ==========================

y = 1/2 * (x + abs(x));

end