function [g] = func_length_scale_localizing(k1,lc,e_nonlocal_eq, e_delta, e_i, e_f,alpha_localizing)
% This function calculates the length scale (localizing gradient)

if e_nonlocal_eq <= e_i
    g = k1 * ((lc^2)/2);

elseif e_nonlocal_eq > e_i && e_nonlocal_eq < e_f
    g = (1 - ((1 - k1) * ((e_f - e_nonlocal_eq)/(e_f - e_delta)))^alpha_localizing) * ((lc^2)/2) ;

elseif e_nonlocal_eq >= e_f
    g = ((lc^2)/2);
    
end



end