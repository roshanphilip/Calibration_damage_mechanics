function loss = test_loss_function(x, p_main_file_path)

% Identify the main, saved and permanent storage file paths
sf                ='\Saved Files';
ps                ='\Perm Storage';
   
main_file_path    = p_main_file_path
save_path         = strcat(main_file_path,sf)
perm_storage_path = strcat(main_file_path,ps)

% Unroll the current guess of input variables  
x1 = x(1);
x2 = x(2);

% Define the circles
% Equation 1: (x - 1)^2 + (y - 1)^2 - 1
eq1 = (x1 - 1)^2 + (x2 - 1)^2 - 1;

% Equation 2: (x - 1.5)^2 + (y - 1)^2 - 0.25
eq2 = (x1 - 1.5)^2 + (x2 - 1)^2 - 0.25;

% Compute the squared differences
loss1 = eq1^2;
loss2 = eq2^2;

% Return the loss components as a vector
loss = [loss1; loss2];
end
